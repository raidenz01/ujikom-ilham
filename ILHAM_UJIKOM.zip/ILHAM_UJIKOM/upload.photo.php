<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Foto - Galeri Irfan</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Navbar -->
    <header>
        <nav>
            <h1>Galeri Irfan</h1>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="tambah_foto.html">Tambah Foto</a></li>
                <li><a href="galeri.html">Galeri</a></li>
                <li><a href="album.html">Album</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <!-- Form Tambah Foto -->
    <section class="form-section">
        <div class="form-card">
            <h2>Tambah Foto Baru</h2>
            <form action="proses_tambah_foto.php" method="POST" enctype="multipart/form-data">
                <!-- Judul Foto -->
                <div class="form-group">
                    <label for="judul">Judul Foto</label>
                    <input type="text" id="judul" name="judul" placeholder="Masukkan judul foto" required>
                </div>

                <!-- Deskripsi Foto -->
                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" rows="3" placeholder="Masukkan deskripsi singkat" required></textarea>
                </div>

                <!-- Pilih Album -->
                <div class="form-group">
                    <label for="album_id">Album</label>
                    <select id="album_id" name="album_id" required>
                        <option value="">Pilih Album</option>
                        <option value="1">Album Liburan</option>
                        <option value="2">Album Keluarga</option>
                    </select>
                </div>

                <!-- Unggah Foto -->
                <div class="form-group">
                    <label for="photo">Unggah Foto</label>
                    <input type="file" id="photo" name="photo" accept="image/*" required>
                </div>

                <!-- Tombol Submit -->
                <div class="form-group">
                    <button type="submit">Unggah Foto</button>
                </div>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Galeri Irfan. All rights reserved.</p>
    </footer>

</body>
</html>
