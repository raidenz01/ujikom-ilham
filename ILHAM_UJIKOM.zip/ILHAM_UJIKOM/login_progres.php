<?php
session_start();

// Konfigurasi koneksi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "galeri";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = $_POST['email'];
  $password = md5($_POST['password']); // Enkripsi password

  // Query untuk memeriksa apakah pengguna ada di database
  $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // Login berhasil, buat session
    $_SESSION['email'] = $email;
    echo "<script>alert('Login berhasil!'); window.location.href='dashboard.php';</script>";
  } else {
    echo "<script>alert('Email atau password salah!'); window.location.href='login.html';</script>";
  }
}

$conn->close();
