<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Foto</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Tambahkan Foto Baru</h1>
        <nav>
            <ul class="navbar">
                <li><a href="gallery.php">Kembali ke Galeri</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="form-container">
            <h2>Unggah Foto</h2>
            <form action="upload_photo.php" method="post" enctype="multipart/form-data">
                <label for="photo">Pilih Foto:</label>
                <input type="file" id="photo" name="photo" accept="image/*" required>
                
                <label for="description">Deskripsi Foto:</label>
                <textarea id="description" name="description" rows="4" required></textarea>
                
                <button type="submit">Unggah Foto</button>
            </form>
        </section>
    </main>
</body>
</html>
