<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri Foto</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Tampilan Rekomendasi Liburan</h1>
        <nav>
            <ul class="navbar">
                <li><a href="home.html">Home</a></li>
                <li><a href="gallery.html">Gallery</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="gallery">
            <div class="photo">
                <img src="img/foto1.jpeg" alt="Di tempat ini buatlah seribu cerita">
            </div>
            <div class="photo">
                <img src="img/foto2.jpeg" alt="Deskripsi Foto 2">
            </div>
            <div class="photo">
                <img src="img/foto3.jpeg" alt="Deskripsi Foto 3">
            </div>
            <!-- Tambahkan lebih banyak foto sesuai kebutuhan -->
        </section>
    </main>
</body>
</html>
